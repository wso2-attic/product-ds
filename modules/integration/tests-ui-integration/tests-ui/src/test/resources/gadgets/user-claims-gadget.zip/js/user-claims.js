gadgets.HubSettings.onConnect = function() {

    gadgets.Hub.subscribe("user-channel", function (topic, data){
        $("#output").text(data);
    });

};
